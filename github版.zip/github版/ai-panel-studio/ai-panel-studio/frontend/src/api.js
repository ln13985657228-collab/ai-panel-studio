import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

export async function createDiscussion(topic, count = 4) {
  const res = await api.post('/discussions', { topic, count });
  return res.data;
}