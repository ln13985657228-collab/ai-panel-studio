﻿import React, { useState, useRef, useCallback } from 'react';
import ConfigPanel from './components/ConfigPanel';
import SpeechHall from './components/SpeechHall';
import Sidebar from './components/Sidebar';
import { createDiscussion } from './api';

function App() {
    const [discussionId, setDiscussionId] = useState(null);
    const [messages, setMessages] = useState([]);
    const [panelists, setPanelists] = useState([]);
    const [consensus, setConsensus] = useState([]);
    const [disagreements, setDisagreements] = useState([]);
    const [isFinished, setIsFinished] = useState(false);
    const wsRef = useRef(null);
    const startSentRef = useRef(false);

    const connectWebSocket = useCallback((id) => {
        if (wsRef.current) {
            wsRef.current.close();
            wsRef.current = null;
        }
        const ws = new WebSocket(`ws://localhost:3000/ws?discussionId=${id}`);
        wsRef.current = ws;

        ws.onopen = () => {
            console.log('✅ WebSocket 连接已打开');
            // 连接建立后，立即发送 start 消息
            if (!startSentRef.current) {
                ws.send(JSON.stringify({ action: 'start' }));
                startSentRef.current = true;
                console.log('🚀 已发送 start 消息');
            }
        };

        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                console.log('📩 收到 WebSocket 消息:', data);
                if (data.type === 'speech') {
                    setMessages(prev => [...prev, data]);
                } else if (data.type === 'consensus') {
                    setConsensus(prev => [...prev, data.content]);
                } else if (data.type === 'disagreement') {
                    setDisagreements(prev => [...prev, data.content]);
                } else if (data.type === 'finished') {
                    setIsFinished(true);
                } else if (data.type === 'info') {
                    console.log('ℹ️ 服务器信息:', data.message);
                } else if (data.type === 'error') {
                    console.error('❌ 服务器错误:', data.message);
                }
            } catch (e) {
                console.warn('非JSON消息:', event.data);
            }
        };

        ws.onclose = (event) => {
            console.log('🔌 WebSocket 连接关闭', event.code, event.reason);
            // 如果连接非正常关闭（非用户主动），可以尝试重连，但为防止死循环，我们限制重连次数
            if (event.code !== 1000 && !isFinished) {
                // 简单重试一次，延迟1秒
                setTimeout(() => {
                    if (!wsRef.current || wsRef.current.readyState === WebSocket.CLOSED) {
                        console.log('🔄 尝试重连...');
                        connectWebSocket(id);
                    }
                }, 1000);
            }
        };

        ws.onerror = (err) => {
            console.error('❌ WebSocket 错误:', err);
        };
    }, [isFinished]);

    const handleStart = async (topic, count) => {
        try {
            const result = await createDiscussion(topic, count);
            setDiscussionId(result.id);
            setPanelists(result.panelists);
            setMessages([]);
            setConsensus([]);
            setDisagreements([]);
            setIsFinished(false);
            startSentRef.current = false;
            // 建立 WebSocket 连接
            connectWebSocket(result.id);
        } catch (error) {
            alert('创建讨论失败: ' + error.message);
        }
    };

    return (
        <div className="flex flex-col h-screen bg-[#0b0e1a] text-gray-200 overflow-hidden">
            <header className="flex-shrink-0 p-4 border-b border-gray-700">
                <h1 className="text-2xl font-bold text-center text-[#f0c27f]">🎙️ AI 圆桌演讲厅</h1>
            </header>
            <div className="flex flex-1 overflow-hidden">
                <div className="w-80 flex-shrink-0 p-4 border-r border-gray-700 overflow-y-auto hidden md:block">
                    <ConfigPanel onStart={handleStart} disabled={!!discussionId && !isFinished} />
                </div>
                <div className="flex-1 p-4 overflow-y-auto">
                    <SpeechHall messages={messages} panelists={panelists} />
                </div>
                <div className="w-72 flex-shrink-0 p-4 border-l border-gray-700 overflow-y-auto hidden lg:block">
                    <Sidebar consensus={consensus} disagreements={disagreements} />
                </div>
            </div>
            <div className="md:hidden flex-shrink-0 p-2 border-t border-gray-700">
                <ConfigPanel onStart={handleStart} disabled={!!discussionId && !isFinished} compact />
            </div>
        </div>
    );
}

export default App;