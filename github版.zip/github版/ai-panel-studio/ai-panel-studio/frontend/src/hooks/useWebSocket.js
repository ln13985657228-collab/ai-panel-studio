import { useEffect, useRef, useState } from 'react';

export function useWebSocket(url, onMessage) {
  const [readyState, setReadyState] = useState(0);
  const wsRef = useRef(null);

  useEffect(() => {
    // 如果 url 为空，关闭现有连接并重置状态
    if (!url) {
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
        setReadyState(0);
      }
      return;
    }

    // 创建新连接前，确保关闭旧连接
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
      setReadyState(0);
    }

    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log('✅ WebSocket 连接已打开');
      setReadyState(ws.readyState);
    };

    ws.onclose = (event) => {
      console.log('🔌 WebSocket 连接已关闭', event.code, event.reason);
      setReadyState(ws.readyState);
      // 注意：不要在这里自动重连，由上层控制
    };

    ws.onerror = (err) => {
      console.error('❌ WebSocket 错误:', err);
    };

    ws.onmessage = (event) => {
      if (onMessage) onMessage(event);
    };

    return () => {
      // 组件卸载或 url 变化时清理
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
        setReadyState(0);
      }
    };
  }, [url, onMessage]);

  const sendMessage = (data) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(data);
      return true;
    } else {
      console.warn('⚠️ WebSocket 未就绪，状态:', wsRef.current ? wsRef.current.readyState : 'null');
      return false;
    }
  };

  return { sendMessage, readyState };
}