import React, { useEffect, useRef } from 'react';

export default function SpeechHall({ messages, panelists }) {
  const containerRef = useRef(null);

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [messages]);

  const colorMap = {};
  panelists.forEach(p => { colorMap[p.id] = p.color; });

  return (
    <div className="h-full flex flex-col">
      <div ref={containerRef} className="flex-1 overflow-y-auto space-y-4 p-2">
        {messages.length === 0 && (
          <div className="text-center text-gray-500 mt-10">等待讨论开始...</div>
        )}
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex items-start gap-3 p-3 rounded-lg bg-[#151a2b] border-l-4`}
               style={{ borderColor: msg.color || '#6C5CE7' }}>
            <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
                 style={{ backgroundColor: msg.color || '#6C5CE7', color: '#fff' }}>
              {msg.name.charAt(0)}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-semibold">{msg.name}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-gray-700 text-gray-300">
                  {msg.role === 'host' ? '🎤 主持人' : '👤 专家'}
                </span>
              </div>
              <p className="mt-1 text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}