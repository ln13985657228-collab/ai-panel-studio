﻿import React, { useState } from 'react';

export default function ConfigPanel({ onStart, disabled, compact }) {
    const [topic, setTopic] = useState('人工智能的伦理挑战');
    const [count, setCount] = useState(4);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!topic.trim()) return;
        onStart(topic, count);
    };

    return (
        <div className={compact ? 'flex flex-wrap items-center gap-2' : ''}>
            <h3 className={compact ? 'text-sm font-semibold' : 'text-lg font-semibold mb-2'}>⚙️ 配置</h3>
            <form onSubmit={handleSubmit} className="space-y-3">
                <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="输入讨论话题"
                    className="w-full px-3 py-2 bg-[#1a1e2e] border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-[#f0c27f]"
                    disabled={disabled}
                />
                <div className="flex items-center gap-3">
                    <label className="text-sm">专家人数：</label>
                    <input
                        type="number"
                        min={2}
                        max={8}
                        value={count}
                        onChange={(e) => setCount(Number(e.target.value))}
                        className="w-16 px-2 py-1 bg-[#1a1e2e] border border-gray-600 rounded text-center"
                        disabled={disabled}
                    />
                </div>
                <button
                    type="submit"
                    className="w-full py-2 bg-[#f0c27f] text-[#0b0e1a] font-bold rounded hover:bg-[#e0b06e] transition disabled:opacity-50"
                    disabled={disabled}
                >
                    {disabled ? '讨论进行中...' : '🚀 开始讨论'}
                </button>
            </form>
        </div>
    );
}