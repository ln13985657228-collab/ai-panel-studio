import React from 'react';

export default function Sidebar({ consensus, disagreements }) {
  return (
    <div className="h-full flex flex-col space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-[#4ECDC4]">✅ 共识</h3>
        <ul className="mt-2 space-y-1">
          {consensus.length === 0 && <li className="text-sm text-gray-500">暂无共识</li>}
          {consensus.map((item, idx) => (
            <li key={idx} className="text-sm bg-[#1a1e2e] p-2 rounded border-l-2 border-[#4ECDC4]">
              {item}
            </li>
          ))}
        </ul>
      </div>
      <div>
        <h3 className="text-lg font-semibold text-[#FF6B6B]">❌ 分歧</h3>
        <ul className="mt-2 space-y-1">
          {disagreements.length === 0 && <li className="text-sm text-gray-500">暂无分歧</li>}
          {disagreements.map((item, idx) => (
            <li key={idx} className="text-sm bg-[#1a1e2e] p-2 rounded border-l-2 border-[#FF6B6B]">
              {item}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}