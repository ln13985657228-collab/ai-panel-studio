const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'panel.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS discussions (
      id TEXT PRIMARY KEY,
      topic TEXT NOT NULL,
      status TEXT DEFAULT 'configuring',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS panelists (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      discussion_id TEXT,
      name TEXT NOT NULL,
      role TEXT CHECK(role IN ('host','expert')),
      field TEXT,
      stance TEXT,
      color TEXT,
      FOREIGN KEY(discussion_id) REFERENCES discussions(id)
    )
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      discussion_id TEXT,
      panelist_id INTEGER,
      content TEXT NOT NULL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(discussion_id) REFERENCES discussions(id),
      FOREIGN KEY(panelist_id) REFERENCES panelists(id)
    )
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS consensus (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      discussion_id TEXT,
      summary TEXT NOT NULL,
      FOREIGN KEY(discussion_id) REFERENCES discussions(id)
    )
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS disagreements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      discussion_id TEXT,
      summary TEXT NOT NULL,
      FOREIGN KEY(discussion_id) REFERENCES discussions(id)
    )
  `);
});

module.exports = db;