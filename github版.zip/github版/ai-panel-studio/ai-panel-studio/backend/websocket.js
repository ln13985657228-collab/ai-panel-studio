const WebSocket = require('ws');
const models = require('./models');
const ai = require('./ai');

const rooms = new Map();

function handleWebSocket(ws, req) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const discussionId = url.searchParams.get('discussionId');
  
  console.log('🔗 新 WebSocket 连接，讨论ID:', discussionId);

  if (!discussionId) {
    ws.send(JSON.stringify({ type: 'error', message: 'Missing discussionId' }));
    ws.close();
    return;
  }

  if (!rooms.has(discussionId)) rooms.set(discussionId, new Set());
  rooms.get(discussionId).add(ws);

  ws.on('message', async (message) => {
    console.log('📩 收到 WebSocket 消息:', message.toString());
    try {
      const data = JSON.parse(message);
      console.log('📩 解析后的数据:', data);
      if (data.action === 'start') {
        console.log('🚀 收到 start 指令，开始讨论:', discussionId);
        await startDiscussion(discussionId);
      }
    } catch (e) {
      console.error('❌ 处理消息出错:', e.message);
      ws.send(JSON.stringify({ type: 'error', message: e.message }));
    }
  });

  ws.on('close', () => {
    console.log('🔌 WebSocket 连接关闭，讨论ID:', discussionId);
    const room = rooms.get(discussionId);
    if (room) {
      room.delete(ws);
      if (room.size === 0) rooms.delete(discussionId);
    }
  });

  ws.send(JSON.stringify({ type: 'info', message: '已连接到讨论房间' }));
  console.log('✅ 已发送连接成功消息到客户端');
}

function broadcast(discussionId, event) {
  const room = rooms.get(discussionId);
  if (!room) {
    console.log('⚠️ 广播失败：房间不存在', discussionId);
    return;
  }
  const payload = JSON.stringify(event);
  console.log('📤 广播消息到房间', discussionId, '事件类型:', event.type);
  room.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  });
}

async function startDiscussion(discussionId) {
  console.log('🎯 startDiscussion 被调用，讨论ID:', discussionId);
  
  try {
    const panelists = await models.getPanelists(discussionId);
    console.log('👥 获取到嘉宾数量:', panelists.length);
    
    const host = panelists.find(p => p.role === 'host');
    const experts = panelists.filter(p => p.role === 'expert');
    
    if (!host) {
      console.error('❌ 未找到主持人');
      broadcast(discussionId, { type: 'error', message: '未找到主持人' });
      return;
    }
    console.log('🎤 主持人:', host.name);
    console.log('👤 专家数量:', experts.length);

    const db = require('./database');
    const row = await new Promise((resolve, reject) => {
      db.get('SELECT topic FROM discussions WHERE id = ?', [discussionId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
    const topic = row.topic;
    console.log('📝 讨论主题:', topic);

    let history = '';

    // 主持人开场
    console.log('📢 主持人开场中...');
    const opening = await ai.hostSpeak(host, topic, '', 'opening');
    console.log('✅ 主持人开场完成，长度:', opening.length);
    broadcast(discussionId, { type: 'speech', panelistId: host.id, name: host.name, role: 'host', color: host.color, content: opening });
    await models.addMessage(discussionId, host.id, opening);
    history += `主持人(${host.name}): ${opening}\n`;

    // 2轮辩论
    for (let r = 0; r < 2; r++) {
      console.log(`🔄 第 ${r+1} 轮开始`);
      for (let expert of experts) {
        console.log(`💬 专家 ${expert.name} 发言中...`);
        const speech = await ai.expertSpeak(expert, topic, history);
        console.log(`✅ 专家 ${expert.name} 发言完成，长度:`, speech.length);
        broadcast(discussionId, { type: 'speech', panelistId: expert.id, name: expert.name, role: 'expert', color: expert.color, content: speech });
        await models.addMessage(discussionId, expert.id, speech);
        history += `${expert.name}(${expert.stance}): ${speech}\n`;
      }
    }

    // 主持人总结
    console.log('📢 主持人总结中...');
    const closing = await ai.hostSpeak(host, topic, history, 'closing');
    console.log('✅ 主持人总结完成，长度:', closing.length);
    broadcast(discussionId, { type: 'speech', panelistId: host.id, name: host.name, role: 'host', color: host.color, content: closing });
    await models.addMessage(discussionId, host.id, closing);
    history += `主持人(${host.name}): ${closing}\n`;

    // 提取共识/分歧
    console.log('📊 提取共识和分歧...');
    const extracted = await ai.extractConsensusAndDisagreement(history, topic);
    console.log('✅ 提取完成，共识:', extracted.consensus.length, '分歧:', extracted.disagreements.length);
    for (let c of extracted.consensus) {
      await models.addConsensus(discussionId, c);
      broadcast(discussionId, { type: 'consensus', content: c });
    }
    for (let d of extracted.disagreements) {
      await models.addDisagreement(discussionId, d);
      broadcast(discussionId, { type: 'disagreement', content: d });
    }

    broadcast(discussionId, { type: 'finished' });
    console.log('🏁 讨论结束，讨论ID:', discussionId);
  } catch (error) {
    console.error('❌ startDiscussion 发生错误:', error);
    broadcast(discussionId, { type: 'error', message: error.message });
  }
}

module.exports = { handleWebSocket, broadcast };