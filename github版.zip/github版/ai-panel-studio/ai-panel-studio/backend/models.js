const db = require('./database');
const { v4: uuidv4 } = require('uuid'); // 需安装：npm install uuid

function createDiscussion(topic, panelists) {
  const id = uuidv4();
  return new Promise((resolve, reject) => {
    db.run('INSERT INTO discussions (id, topic, status) VALUES (?, ?, ?)', [id, topic, 'ongoing'], function(err) {
      if (err) reject(err);
      const stmt = db.prepare('INSERT INTO panelists (discussion_id, name, role, field, stance, color) VALUES (?, ?, ?, ?, ?, ?)');
      panelists.forEach(p => {
        stmt.run(id, p.name, p.role, p.field, p.stance, p.color);
      });
      stmt.finalize(err2 => {
        if (err2) reject(err2);
        resolve(id);
      });
    });
  });
}

function addMessage(discussionId, panelistId, content) {
  return new Promise((resolve, reject) => {
    db.run('INSERT INTO messages (discussion_id, panelist_id, content) VALUES (?, ?, ?)',
      [discussionId, panelistId, content], function(err) {
        if (err) reject(err);
        resolve(this.lastID);
      });
  });
}

function getMessages(discussionId) {
  return new Promise((resolve, reject) => {
    db.all(`
      SELECT m.*, p.name, p.role, p.color
      FROM messages m
      JOIN panelists p ON m.panelist_id = p.id
      WHERE m.discussion_id = ?
      ORDER BY m.timestamp ASC
    `, [discussionId], (err, rows) => {
      if (err) reject(err);
      resolve(rows);
    });
  });
}

function getPanelists(discussionId) {
  return new Promise((resolve, reject) => {
    db.all('SELECT * FROM panelists WHERE discussion_id = ?', [discussionId], (err, rows) => {
      if (err) reject(err);
      resolve(rows);
    });
  });
}

function addConsensus(discussionId, summary) {
  return new Promise((resolve, reject) => {
    db.run('INSERT INTO consensus (discussion_id, summary) VALUES (?, ?)', [discussionId, summary], function(err) {
      if (err) reject(err);
      resolve(this.lastID);
    });
  });
}

function addDisagreement(discussionId, summary) {
  return new Promise((resolve, reject) => {
    db.run('INSERT INTO disagreements (discussion_id, summary) VALUES (?, ?)', [discussionId, summary], function(err) {
      if (err) reject(err);
      resolve(this.lastID);
    });
  });
}

function getConsensus(discussionId) {
  return new Promise((resolve, reject) => {
    db.all('SELECT * FROM consensus WHERE discussion_id = ?', [discussionId], (err, rows) => {
      if (err) reject(err);
      resolve(rows);
    });
  });
}

function getDisagreements(discussionId) {
  return new Promise((resolve, reject) => {
    db.all('SELECT * FROM disagreements WHERE discussion_id = ?', [discussionId], (err, rows) => {
      if (err) reject(err);
      resolve(rows);
    });
  });
}

module.exports = {
  createDiscussion,
  addMessage,
  getMessages,
  getPanelists,
  addConsensus,
  addDisagreement,
  getConsensus,
  getDisagreements
};