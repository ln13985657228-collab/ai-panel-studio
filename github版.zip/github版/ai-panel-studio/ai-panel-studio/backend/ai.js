const axios = require('axios');

async function callDeepseek(prompt, temperature = 0.7) {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (!apiKey) {
    console.error('❌ DEEPSEEK_API_KEY 未设置');
    throw new Error('Missing DEEPSEEK_API_KEY');
  }
  
  console.log('🌐 正在调用 Deepseek API，提示词长度:', prompt.length);
  try {
    const response = await axios.post(
      'https://api.deepseek.com/v1/chat/completions',
      {
        model: 'deepseek-chat',
        messages: [{ role: 'user', content: prompt }],
        temperature: temperature,
      },
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        timeout: 60000, // 60秒超时
      }
    );
    const content = response.data.choices[0].message.content;
    console.log('✅ Deepseek API 调用成功，响应长度:', content.length);
    return content;
  } catch (error) {
    console.error('❌ Deepseek API 调用失败:');
    if (error.response) {
      console.error('  状态码:', error.response.status);
      console.error('  错误数据:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.error('  错误信息:', error.message);
    }
    throw error;
  }
}

async function generatePanelists(topic, count) {
  console.log('🎨 生成嘉宾，主题:', topic, '人数:', count);
  const prompt = `
你是一个活动策划专家。请为主题"${topic}"生成 ${count} 位专家和 1 位主持人。

要求：
- 每位专家需有：姓名（中文）、领域、立场（支持/反对/中立）
- 主持人需有：姓名、风格（如：严谨、幽默、犀利）
- 每位嘉宾分配一个十六进制颜色代码

输出格式必须为纯JSON：
{
  "host": { "name": "张明", "style": "严谨" },
  "experts": [
    { "name": "李华", "field": "人工智能", "stance": "支持", "color": "#FF6B6B" }
  ]
}
`;
  const result = await callDeepseek(prompt, 0.8);
  try {
    const parsed = JSON.parse(result);
    console.log('✅ 嘉宾生成成功');
    return parsed;
  } catch (e) {
    console.error('❌ 解析嘉宾JSON失败:', result);
    throw new Error('AI返回格式错误');
  }
}

async function expertSpeak(expert, topic, history) {
  console.log('💬 专家发言:', expert.name);
  const prompt = `
你是 ${expert.name}，领域：${expert.field}，立场：${expert.stance}。

你正在参与一场AI圆桌辩论，主题：${topic}。

历史对话：
${history}

请输出一段简短有力的发言（100-200字），可以反驳或补充前人观点。
`;
  return await callDeepseek(prompt, 0.9);
}

async function hostSpeak(host, topic, history, phase) {
  console.log('🎤 主持人发言，阶段:', phase);
  let prompt;
  if (phase === 'opening') {
    prompt = `你是主持人 ${host.name}，风格：${host.style}。请为圆桌讨论"${topic}"致开场词，介绍主题和嘉宾。`;
  } else if (phase === 'closing') {
    prompt = `
你是主持人 ${host.name}，请根据以下讨论内容进行总结：

讨论主题：${topic}
完整对话：
${history}

要求：
1. 总结各方核心观点
2. 指出至少1个共识点
3. 指出至少1个分歧点
输出格式：先总结，再列出共识（用"✅ 共识："开头），分歧（用"❌ 分歧："开头）。
`;
  }
  return await callDeepseek(prompt, 0.7);
}

async function extractConsensusAndDisagreement(history, topic) {
  console.log('📊 提取共识和分歧...');
  const prompt = `
根据以下关于"${topic}"的圆桌讨论内容，提取出共识点和分歧点。

讨论记录：
${history}

请输出JSON格式：
{
  "consensus": ["共识1", "共识2", ...],
  "disagreements": ["分歧1", "分歧2", ...]
}
仅输出JSON。
`;
  const result = await callDeepseek(prompt, 0.6);
  try {
    const parsed = JSON.parse(result);
    console.log('✅ 提取成功，共识:', parsed.consensus.length, '分歧:', parsed.disagreements.length);
    return parsed;
  } catch (e) {
    console.error('❌ 解析共识/分歧JSON失败:', result);
    return { consensus: [], disagreements: [] };
  }
}

module.exports = {
  callDeepseek,
  generatePanelists,
  expertSpeak,
  hostSpeak,
  extractConsensusAndDisagreement
};