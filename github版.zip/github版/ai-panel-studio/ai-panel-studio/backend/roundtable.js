const axios = require("axios");

// ===== 1. 生成角色 =====
async function generateAgents(topic) {
  const prompt = `
你是系统，请为圆桌会议生成角色：

主题：${topic}

要求：
- 1个主持人
- 3个专家
- 输出JSON格式：

{
  "host": {"name": "", "style": ""},
  "experts": [
    {"name": "", "field": ""},
    {"name": "", "field": ""},
    {"name": "", "field": ""}
  ]
}
`;

  const res = await callAI(prompt);
  return res;
}

// ===== 2. 单个AI发言 =====
async function speak(role, topic, history) {
  const prompt = `
你是${role.name}。

讨论主题：${topic}

历史对话：
${history}

要求：
- 保持角色一致
- 输出1段发言
`;

  const res = await callAI(prompt);
  return res;
}

// ===== 3. AI调用（先用模拟）=====
async function callAI(prompt) {
  // ⚠️ 这里先用模拟（避免你卡API）
  return {
    text: "（AI模拟回复）这里是AI生成的内容：" + prompt.slice(0, 50),
  };
}

module.exports = {
  generateAgents,
  speak,
};