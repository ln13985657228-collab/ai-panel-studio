require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const db = require('../database');
const models = require('../models');
const ai = require('../ai');

const sampleTopics = [
  '人工智能对齐风险',
  '远程办公的长期影响',
  '元宇宙教育的可行性',
  '基因编辑伦理边界',
  '低代码平台对程序员的影响'
];

async function init() {
  console.log('📦 开始插入样例数据...');
  for (let topic of sampleTopics) {
    try {
      const generated = await ai.generatePanelists(topic, 4);
      const panelists = [
        { name: generated.host.name, role: 'host', field: '主持人', stance: '中立', color: '#FFD93D' },
        ...generated.experts.map(e => ({
          name: e.name,
          role: 'expert',
          field: e.field,
          stance: e.stance,
          color: e.color || '#6C5CE7'
        }))
      ];
      const id = await models.createDiscussion(topic, panelists);
      console.log(`✅ 创建讨论: ${topic} (${id})`);
    } catch (e) {
      console.error(`❌ 失败: ${topic}`, e.message);
    }
  }
  console.log('🎉 初始化完成。');
  db.close();
}

init();