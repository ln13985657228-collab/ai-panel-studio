require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const WebSocket = require('ws');
const routes = require('./routes');
const wsHandler = require('./websocket');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/api', routes);

const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });

wss.on('connection', (ws, req) => {
  wsHandler.handleWebSocket(ws, req);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`✅ 后端运行在 http://localhost:${PORT}`);
  console.log(`✅ WebSocket端点: ws://localhost:${PORT}/ws`);
});