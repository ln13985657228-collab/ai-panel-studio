const express = require('express');
const router = express.Router();
const models = require('./models');
const ai = require('./ai');

router.post('/discussions', async (req, res) => {
  const { topic, count = 4 } = req.body;
  if (!topic) return res.status(400).json({ error: 'topic required' });
  
  try {
    const generated = await ai.generatePanelists(topic, count);
    const panelists = [
      { name: generated.host.name, role: 'host', field: '主持人', stance: '中立', color: '#FFD93D' },
      ...generated.experts.map(e => ({
        name: e.name,
        role: 'expert',
        field: e.field,
        stance: e.stance,
        color: e.color || '#6C5CE7'
      }))
    ];
    const discussionId = await models.createDiscussion(topic, panelists);
    const storedPanelists = await models.getPanelists(discussionId);
    res.status(201).json({ id: discussionId, topic, panelists: storedPanelists });
  } catch (error) {
    console.error('创建讨论失败:', error);
    res.status(500).json({ error: error.message });
  }
});

router.get('/discussions/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const messages = await models.getMessages(id);
    const panelists = await models.getPanelists(id);
    const consensus = await models.getConsensus(id);
    const disagreements = await models.getDisagreements(id);
    res.json({ messages, panelists, consensus, disagreements });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/discussions', async (req, res) => {
  const db = require('./database');
  db.all('SELECT id, topic, status, created_at FROM discussions ORDER BY created_at DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

module.exports = router;